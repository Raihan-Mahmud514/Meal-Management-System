
package meal.management.system2;


public class MealManagementSystem2 {

    
    public static void main(String[] args) {
        
        Login ln = new Login();
        ln.setVisible(true);
       
        
        
    }
    
}
